import fs from "node:fs";
import path from "node:path";
import { env } from "../config/index.js";
import type { Campaign, ContentJob } from "../types/index.js";
import { logger } from "../utils/logger.js";

const dataDir = path.join(env.STORAGE_ROOT, "data");
fs.mkdirSync(dataDir, { recursive: true });

const campaignsPath = path.join(dataDir, "campaigns.json");
const jobsPath = path.join(dataDir, "jobs.json");

function readJson<T>(file: string, fallback: T): T {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf8")) as T;
  } catch {
    return fallback;
  }
}

function writeJson(file: string, data: unknown) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
}

function now() {
  return new Date().toISOString();
}

type CampaignStore = Record<string, Campaign>;
type JobStore = Record<string, ContentJob>;

export const campaigns = {
  create(c: Campaign) {
    const store = readJson<CampaignStore>(campaignsPath, {});
    store[c.id] = c;
    writeJson(campaignsPath, store);
  },
  get(id: string): Campaign | null {
    const store = readJson<CampaignStore>(campaignsPath, {});
    return store[id] ?? null;
  },
  update(id: string, patch: Partial<Campaign>) {
    const store = readJson<CampaignStore>(campaignsPath, {});
    const existing = store[id];
    if (!existing) throw new Error(`Campaign ${id} not found`);
    const next = { ...existing, ...patch, updated_at: now() };
    store[id] = next;
    writeJson(campaignsPath, store);
    return next;
  },
  list(limit = 50): Campaign[] {
    const store = readJson<CampaignStore>(campaignsPath, {});
    return Object.values(store)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .slice(0, limit);
  },
};

export const jobs = {
  create(j: ContentJob) {
    const store = readJson<JobStore>(jobsPath, {});
    store[j.id] = j;
    writeJson(jobsPath, store);
  },
  get(id: string): ContentJob | null {
    const store = readJson<JobStore>(jobsPath, {});
    return store[id] ?? null;
  },
  update(id: string, patch: Partial<ContentJob>) {
    const store = readJson<JobStore>(jobsPath, {});
    const existing = store[id];
    if (!existing) throw new Error(`Job ${id} not found`);
    const next = { ...existing, ...patch, updated_at: now() };
    store[id] = next;
    writeJson(jobsPath, store);
    return next;
  },
  listByCampaign(campaignId: string): ContentJob[] {
    const store = readJson<JobStore>(jobsPath, {});
    return Object.values(store)
      .filter((j) => j.campaign_id === campaignId)
      .sort((a, b) => a.created_at.localeCompare(b.created_at));
  },
  list(limit = 50): ContentJob[] {
    const store = readJson<JobStore>(jobsPath, {});
    return Object.values(store)
      .sort((a, b) => b.created_at.localeCompare(a.created_at))
      .slice(0, limit);
  },
};

logger.info({ dataDir }, "JSON file store ready");
