import { randomUUID as uuid } from "node:crypto";
import { CampaignInputSchema, type CampaignInput, type ContentJob, type Campaign } from "../types/index.js";
import { campaigns, jobs } from "../db/index.js";
import { runResearch } from "../agents/research.js";
import { runStrategy } from "../agents/strategy.js";
import { runHooks } from "../agents/hook.js";
import { runScript } from "../agents/script.js";
import { runVisualDirector } from "../agents/visual.js";
import { runQC } from "../agents/qc.js";
import { renderVisualSpec, publicAssetUrl } from "../services/hyperframes.js";
import { createPost, hasBuffer, resolveChannelIds } from "../services/buffer.js";
import { env } from "../config/index.js";
import { logger } from "../utils/logger.js";
import { hasLLM } from "../services/llm.js";
import fs from "node:fs";
import path from "node:path";

function now() {
  return new Date().toISOString();
}

export async function createCampaign(raw: unknown): Promise<Campaign> {
  const input = CampaignInputSchema.parse(raw);
  const id = uuid();
  const campaign: Campaign = {
    id,
    input,
    status: "planning",
    job_ids: [],
    created_at: now(),
    updated_at: now(),
  };
  campaigns.create(campaign);

  // V1: one content job per campaign (extend to volume later)
  const jobId = uuid();
  const job: ContentJob = {
    id: jobId,
    campaign_id: id,
    status: "pending",
    input,
    revision_count: 0,
    created_at: now(),
    updated_at: now(),
  };
  jobs.create(job);
  campaigns.update(id, { job_ids: [jobId], status: "producing" });
  logger.info({ campaignId: id, jobId }, "Campaign created");
  return campaigns.get(id)!;
}

export async function runJob(jobId: string): Promise<ContentJob> {
  let job = jobs.get(jobId);
  if (!job) throw new Error(`Job ${jobId} not found`);

  if (!hasLLM()) {
    job = jobs.update(jobId, {
      status: "failed",
      error: "OPENAI_API_KEY not configured",
    });
    return job;
  }

  try {
    // 1. Research
    job = jobs.update(jobId, { status: "researching" });
    const research = await runResearch(job.input);
    job = jobs.update(jobId, { research });

    // 2. Strategy
    job = jobs.update(jobId, { status: "strategizing" });
    const strategy = await runStrategy(job.input, research);
    job = jobs.update(jobId, { strategy });

    // 3. Hooks
    const { hooks, selected } = await runHooks(job.input, strategy);
    job = jobs.update(jobId, { hooks, selected_hook: selected });

    // 4. Script
    job = jobs.update(jobId, { status: "scripting" });
    const script = await runScript(job.input, strategy, selected);
    job = jobs.update(jobId, { script });

    // 5. Visual
    job = jobs.update(jobId, { status: "visualizing" });
    let visual = await runVisualDirector(job.input, strategy, script);
    job = jobs.update(jobId, { visual });

    // 6. Render + QC loop
    let pass = false;
    while (!pass && job.revision_count <= env.MAX_REVISIONS) {
      job = jobs.update(jobId, { status: "rendering" });
      const render = await renderVisualSpec(jobId, visual);
      if (!render.renderOk) {
        job = jobs.update(jobId, {
          status: "failed",
          error: `Render failed: ${render.renderOutput.slice(0, 500)}`,
        });
        return job;
      }

      // Copy into public assets dir for serving
      const publicDir = path.join(env.STORAGE_ROOT, "assets");
      fs.mkdirSync(publicDir, { recursive: true });
      const publicPath = path.join(publicDir, `${jobId}.mp4`);
      fs.copyFileSync(render.outputPath, publicPath);
      const publicUrl = publicAssetUrl(jobId);

      job = jobs.update(jobId, {
        status: "qc",
        render_path: render.outputPath,
        public_url: publicUrl,
      });

      const qc = await runQC(script, visual, [render.lintOutput]);
      job = jobs.update(jobId, { qc });

      if (qc.pass) {
        pass = true;
      } else if (job.revision_count < env.MAX_REVISIONS) {
        logger.info({ jobId, overall: qc.overall }, "QC failed — revising visual");
        job = jobs.update(jobId, {
          status: "revising",
          revision_count: job.revision_count + 1,
        });
        // Light revision: ask visual director again with QC notes
        visual = await runVisualDirector(job.input, strategy, script);
        job = jobs.update(jobId, { visual });
      } else {
        logger.warn({ jobId }, "Max revisions reached — publishing with best effort");
        pass = true;
      }
    }

    // 7. Publish via Buffer (optional)
    if (hasBuffer() && job.public_url) {
      job = jobs.update(jobId, { status: "publishing" });
      try {
        const channelMap = await resolveChannelIds(
          env.BUFFER_ORG_ID!,
          job.input.platforms
        );
        const posts: Record<string, unknown> = {};
        const caption = `${job.selected_hook?.text ?? ""}\n\n${job.script?.full_script?.slice(0, 400) ?? ""}\n\n${job.strategy?.cta ?? ""}`.trim();

        for (const platform of job.input.platforms) {
          const channelId = channelMap[platform];
          if (!channelId) {
            posts[platform] = { error: "No Buffer channel mapped" };
            continue;
          }
          const result = await createPost({
            channelId,
            text: caption,
            videoUrl: job.public_url,
            saveToDraft: true, // safer default for first run
          });
          posts[platform] = result;
        }
        job = jobs.update(jobId, { platform_posts: posts, status: "completed" });
      } catch (pubErr: any) {
        logger.error({ err: pubErr.message }, "Buffer publish failed");
        job = jobs.update(jobId, {
          status: "completed",
          error: `Published assets ready; Buffer error: ${pubErr.message}`,
          platform_posts: { error: pubErr.message },
        });
      }
    } else {
      job = jobs.update(jobId, { status: "completed" });
    }

    campaigns.update(job.campaign_id, { status: "completed" });
    logger.info({ jobId, status: job.status }, "Job finished");
    return jobs.get(jobId)!;
  } catch (err: any) {
    logger.error({ jobId, err: err.message }, "Job failed");
    return jobs.update(jobId, { status: "failed", error: err.message });
  }
}

export async function runCampaign(campaignId: string): Promise<Campaign> {
  const campaign = campaigns.get(campaignId);
  if (!campaign) throw new Error(`Campaign ${campaignId} not found`);
  for (const jobId of campaign.job_ids) {
    await runJob(jobId);
  }
  return campaigns.get(campaignId)!;
}
