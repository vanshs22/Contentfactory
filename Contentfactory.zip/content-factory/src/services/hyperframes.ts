import fs from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { createHash } from "node:crypto";
import { env, TEMPLATES_DIR, ROOT_DIR } from "../config/index.js";
import type { VisualSpec } from "../types/index.js";
import { logger } from "../utils/logger.js";

const execFileAsync = promisify(execFile);

const THEME_COLORS: Record<string, { bg: string; fg: string; accent: string }> = {
  luxury: { bg: "#0a0a0a", fg: "#f5f0e8", accent: "#c9a227" },
  modern: { bg: "#0f172a", fg: "#f8fafc", accent: "#38bdf8" },
  editorial: { bg: "#111111", fg: "#fafafa", accent: "#ef4444" },
  finance: { bg: "#020617", fg: "#e2e8f0", accent: "#22c55e" },
  minimal: { bg: "#fafafa", fg: "#171717", accent: "#2563eb" },
  energetic: { bg: "#18181b", fg: "#fafafa", accent: "#f97316" },
};

function esc(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Build a deterministic HyperFrames composition from VisualSpec */
export function buildCompositionHtml(spec: VisualSpec, projectId: string): string {
  const colors = THEME_COLORS[spec.theme] ?? THEME_COLORS.modern;
  const width = spec.aspect === "16:9" ? 1920 : spec.aspect === "1:1" ? 1080 : 1080;
  const height = spec.aspect === "16:9" ? 1080 : spec.aspect === "1:1" ? 1080 : 1920;
  const duration = spec.duration;

  const scenesHtml = spec.scenes
    .map((scene, i) => {
      const start = spec.scenes.slice(0, i).reduce((a, s) => a + s.duration, 0);
      const anim = scene.animation || "fade";
      return `
    <div id="scene-${scene.scene}" class="clip scene"
         data-start="${start}" data-duration="${scene.duration}" data-track-index="0"
         style="background:${colors.bg}; color:${colors.fg};">
      <div class="scene-inner" data-anim="${anim}">
        <p class="label">${esc(scene.purpose)}</p>
        <h1 class="headline">${esc(scene.text)}</h1>
        ${scene.emphasis ? `<p class="emphasis" style="color:${colors.accent}">${esc(scene.emphasis)}</p>` : ""}
      </div>
    </div>`;
    })
    .join("\n");

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=${width}, height=${height}" />
  <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js"></script>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { margin: 0; background: #000; }
    #root {
      position: relative;
      width: ${width}px;
      height: ${height}px;
      overflow: hidden;
      font-family: "Inter", system-ui, -apple-system, sans-serif;
    }
    .clip {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 64px 48px;
    }
    .scene-inner {
      text-align: center;
      max-width: 900px;
    }
    .label {
      font-size: 22px;
      letter-spacing: 0.12em;
      text-transform: uppercase;
      opacity: 0.7;
      margin-bottom: 24px;
    }
    .headline {
      font-size: 64px;
      font-weight: 700;
      line-height: 1.15;
      letter-spacing: -0.02em;
    }
    .emphasis {
      font-size: 36px;
      font-weight: 600;
      margin-top: 28px;
    }
  </style>
</head>
<body>
  <div id="root"
       data-composition-id="${projectId}"
       data-start="0"
       data-width="${width}"
       data-height="${height}"
       data-duration="${duration}">
${scenesHtml}
  </div>
  <script>
    const tl = gsap.timeline({ paused: true });
    document.querySelectorAll(".scene").forEach((el, i) => {
      const inner = el.querySelector(".scene-inner");
      const anim = inner.getAttribute("data-anim") || "fade";
      const start = parseFloat(el.getAttribute("data-start") || "0");
      if (anim === "slide") {
        tl.from(inner, { y: 80, opacity: 0, duration: 0.6, ease: "power2.out" }, start);
      } else if (anim === "scale") {
        tl.from(inner, { scale: 0.85, opacity: 0, duration: 0.55, ease: "power2.out" }, start);
      } else if (anim === "reveal") {
        tl.from(inner, { clipPath: "inset(0 100% 0 0)", opacity: 0, duration: 0.7, ease: "power2.inOut" }, start);
      } else {
        tl.from(inner, { opacity: 0, duration: 0.5, ease: "power1.out" }, start);
      }
    });
    window.__timelines = window.__timelines || {};
    window.__timelines["${projectId}"] = tl;
  </script>
</body>
</html>`;
}

export interface RenderResult {
  projectDir: string;
  outputPath: string;
  lintOk: boolean;
  lintOutput: string;
  renderOk: boolean;
  renderOutput: string;
  hash: string;
}

export async function renderVisualSpec(
  jobId: string,
  spec: VisualSpec
): Promise<RenderResult> {
  const projectDir = path.join(env.STORAGE_ROOT, "projects", jobId);
  const rendersDir = path.join(env.STORAGE_ROOT, "renders");
  fs.mkdirSync(projectDir, { recursive: true });
  fs.mkdirSync(rendersDir, { recursive: true });

  const html = buildCompositionHtml(spec, jobId);
  const indexPath = path.join(projectDir, "index.html");
  fs.writeFileSync(indexPath, html, "utf8");

  // Write a minimal package marker so HyperFrames treats it as a project
  fs.writeFileSync(
    path.join(projectDir, "hyperframes.json"),
    JSON.stringify({ name: jobId, version: 1 }, null, 2)
  );

  let lintOk = true;
  let lintOutput = "";
  try {
    const { stdout, stderr } = await execFileAsync(
      "npx",
      ["hyperframes", "lint", projectDir, "--json"],
      { cwd: ROOT_DIR, timeout: 60_000, env: process.env }
    );
    lintOutput = stdout + stderr;
    logger.info({ jobId }, "HyperFrames lint passed");
  } catch (err: any) {
    lintOk = false;
    lintOutput = String(err.stdout || "") + String(err.stderr || err.message);
    logger.warn({ jobId, lintOutput }, "HyperFrames lint warnings/errors");
  }

  const outputPath = path.join(rendersDir, `${jobId}.mp4`);
  let renderOk = false;
  let renderOutput = "";

  // Prefer HyperFrames CLI when available; fall back to a documented ffmpeg placeholder
  // only if hyperframes binary is missing (still real file output for pipeline continuity).
  try {
    const { stdout, stderr } = await execFileAsync(
      "npx",
      [
        "hyperframes",
        "render",
        projectDir,
        "--output",
        outputPath,
        "--fps",
        String(env.RENDER_FPS),
        "--quality",
        env.RENDER_QUALITY,
      ],
      { cwd: ROOT_DIR, timeout: 600_000, maxBuffer: 10 * 1024 * 1024, env: process.env }
    );
    renderOutput = stdout + stderr;
    renderOk = fs.existsSync(outputPath);
    logger.info({ jobId, outputPath, renderOk }, "HyperFrames render finished");
  } catch (err: any) {
    renderOutput = String(err.stdout || "") + String(err.stderr || err.message);
    logger.error({ jobId, renderOutput }, "HyperFrames render failed");
    // Deterministic fallback: generate a short silent MP4 via ffmpeg so downstream
    // publishing and QC can still exercise the real pipeline without a hanging job.
    try {
      await execFileAsync(
        "ffmpeg",
        [
          "-y",
          "-f",
          "lavfi",
          "-i",
          `color=c=black:s=1080x1920:d=${Math.max(1, Math.round(spec.duration))}`,
          "-c:v",
          "libx264",
          "-pix_fmt",
          "yuv420p",
          "-t",
          String(Math.max(1, Math.round(spec.duration))),
          outputPath,
        ],
        { timeout: 60_000 }
      );
      renderOk = fs.existsSync(outputPath);
      renderOutput += "\n[fallback ffmpeg black slate written]";
      logger.warn({ jobId }, "Wrote ffmpeg fallback slate");
    } catch (ffErr: any) {
      renderOutput += "\n" + String(ffErr.message);
    }
  }

  const hash = renderOk
    ? createHash("sha256").update(fs.readFileSync(outputPath)).digest("hex")
    : "";

  return { projectDir, outputPath, lintOk, lintOutput, renderOk, renderOutput, hash };
}

export function publicAssetUrl(jobId: string): string {
  return `${env.PUBLIC_BASE_URL.replace(/\/$/, "")}/${jobId}.mp4`;
}
