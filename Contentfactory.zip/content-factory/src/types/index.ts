import { z } from "zod";

export const PlatformSchema = z.enum([
  "instagram",
  "tiktok",
  "youtube",
  "x",
  "linkedin",
  "facebook",
  "threads",
]);
export type Platform = z.infer<typeof PlatformSchema>;

export const CampaignInputSchema = z.object({
  goal: z.string().min(1),
  niche: z.string().min(1),
  audience: z.string().min(1),
  platforms: z.array(PlatformSchema).min(1),
  brand: z
    .object({
      name: z.string().optional(),
      voice: z.string().optional(),
      colors: z.array(z.string()).optional(),
      logoUrl: z.string().url().optional(),
    })
    .default({}),
  content_goal: z.enum(["growth", "engagement", "conversion", "awareness"]).default("growth"),
  volume: z.number().int().min(1).max(90).default(7),
  duration_days: z.number().int().min(1).max(90).default(7),
});
export type CampaignInput = z.infer<typeof CampaignInputSchema>;

export const ResearchResultSchema = z.object({
  trends: z.array(z.string()),
  statistics: z.array(z.object({ claim: z.string(), source: z.string().optional() })),
  stories: z.array(z.string()),
  questions: z.array(z.string()),
  competitors: z.array(z.string()),
  sources: z.array(z.string()),
  summary: z.string(),
});
export type ResearchResult = z.infer<typeof ResearchResultSchema>;

export const StrategyResultSchema = z.object({
  topic: z.string(),
  angle: z.string(),
  format: z.enum(["reel", "carousel", "short", "thread", "post"]),
  platform_priority: z.array(PlatformSchema),
  objective: z.string(),
  cta: z.string(),
  expected_outcome: z.string(),
  structure: z.object({
    hook_sec: z.number(),
    problem_sec: z.number(),
    value_sec: z.number(),
    payoff_sec: z.number(),
    cta_sec: z.number(),
  }),
});
export type StrategyResult = z.infer<typeof StrategyResultSchema>;

export const HookSchema = z.object({
  text: z.string(),
  scores: z.object({
    curiosity: z.number(),
    clarity: z.number(),
    novelty: z.number(),
    emotional_impact: z.number(),
    audience_relevance: z.number(),
    scroll_stop: z.number(),
  }),
  total: z.number(),
});
export type Hook = z.infer<typeof HookSchema>;

export const ScriptResultSchema = z.object({
  hook: z.string(),
  full_script: z.string(),
  beats: z.array(
    z.object({
      start: z.number(),
      end: z.number(),
      type: z.enum(["hook", "problem", "value", "payoff", "cta"]),
      text: z.string(),
    })
  ),
  duration_sec: z.number(),
  word_count: z.number(),
});
export type ScriptResult = z.infer<typeof ScriptResultSchema>;

export const SceneSpecSchema = z.object({
  scene: z.number(),
  duration: z.number(),
  purpose: z.string(),
  visual: z.string(),
  animation: z.string(),
  text: z.string(),
  emphasis: z.string().optional(),
  background: z.string().optional(),
});
export type SceneSpec = z.infer<typeof SceneSpecSchema>;

export const VisualSpecSchema = z.object({
  template: z.string(),
  theme: z.string(),
  duration: z.number(),
  aspect: z.enum(["9:16", "16:9", "1:1"]).default("9:16"),
  scenes: z.array(SceneSpecSchema),
  brand_colors: z.array(z.string()).optional(),
  logo_url: z.string().optional(),
});
export type VisualSpec = z.infer<typeof VisualSpecSchema>;

export const QCScoreSchema = z.object({
  visual_quality: z.number(),
  typography: z.number(),
  readability: z.number(),
  composition: z.number(),
  brand_consistency: z.number(),
  storytelling: z.number(),
  hook_strength: z.number(),
  technical_validity: z.number(),
  overall: z.number(),
  notes: z.array(z.string()),
  pass: z.boolean(),
});
export type QCScore = z.infer<typeof QCScoreSchema>;

export type JobStatus =
  | "pending"
  | "researching"
  | "strategizing"
  | "scripting"
  | "visualizing"
  | "rendering"
  | "qc"
  | "publishing"
  | "completed"
  | "failed"
  | "revising";

export interface ContentJob {
  id: string;
  campaign_id: string;
  status: JobStatus;
  input: CampaignInput;
  research?: ResearchResult;
  strategy?: StrategyResult;
  hooks?: Hook[];
  selected_hook?: Hook;
  script?: ScriptResult;
  visual?: VisualSpec;
  render_path?: string;
  public_url?: string;
  qc?: QCScore;
  revision_count: number;
  platform_posts?: Record<string, unknown>;
  error?: string;
  created_at: string;
  updated_at: string;
}

export interface Campaign {
  id: string;
  input: CampaignInput;
  status: "planning" | "producing" | "completed" | "failed";
  job_ids: string[];
  created_at: string;
  updated_at: string;
}
