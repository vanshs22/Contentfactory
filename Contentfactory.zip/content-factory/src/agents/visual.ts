import { chatJson } from "../services/llm.js";
import { env } from "../config/index.js";
import {
  VisualSpecSchema,
  type CampaignInput,
  type StrategyResult,
  type ScriptResult,
  type VisualSpec,
} from "../types/index.js";
import { logger } from "../utils/logger.js";

const SYSTEM = `You are the Visual Director for a HyperFrames-based content factory.
Convert a spoken script into a deterministic scene specification for HTML video.
Choose template from: reel-editorial, reel-cinematic, reel-finance, reel-minimal, reel-news.
Choose theme from: luxury, modern, editorial, finance, minimal, energetic.
Each scene needs: scene number, duration (seconds), purpose, visual description, animation (fade|slide|scale|reveal|counter|kinetic-type), text on screen, optional emphasis and background.
Scenes must sum to the script duration.
Prefer bold kinetic typography and clear hierarchy for 9:16 vertical video.
Return only JSON matching the visual spec schema.`;

export async function runVisualDirector(
  input: CampaignInput,
  strategy: StrategyResult,
  script: ScriptResult
): Promise<VisualSpec> {
  logger.info("Visual Director starting");
  const user = `Brand: ${JSON.stringify(input.brand)}
Strategy: ${JSON.stringify(strategy)}
Script: ${JSON.stringify(script)}

Produce VisualSpec with template, theme, duration, aspect "9:16", and scenes array.`;

  const result = await chatJson(
    env.VISUAL_MODEL,
    SYSTEM,
    user,
    VisualSpecSchema,
    { temperature: 0.4 }
  );
  logger.info({ template: result.template, scenes: result.scenes.length }, "Visual spec ready");
  return result;
}
