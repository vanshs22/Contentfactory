# AI Content & Digital Asset Factory

Production system that turns one idea into researched, scripted, HyperFrames-rendered, QC-gated, Buffer-published short-form content.

**Architecture**

```
Director → Research → Strategy → Hook → Script → Visual Director → HyperFrames → QC → Storage → Buffer
```

HyperFrames is the deterministic visual production engine.  
n8n is the external orchestration layer (optional).  
The Director is the brain.

## Requirements

- Node.js >= 22
- FFmpeg on PATH
- Optional: `npx hyperframes` (installs on demand)
- OpenAI-compatible API key
- Optional: Buffer GraphQL API key + org ID

## Quick start

```bash
cp .env.example .env
# edit OPENAI_API_KEY (and BUFFER_* if publishing)

npm install --legacy-peer-deps
npm run dev
```

API listens on `http://localhost:3100`.

### Create + run a campaign (HTTP)

```bash
curl -X POST http://localhost:3100/production/run \
  -H 'Content-Type: application/json' \
  -d '{
    "goal": "30 days of growth content",
    "niche": "luxury real estate",
    "audience": "US investors",
    "platforms": ["instagram", "tiktok", "youtube"],
    "content_goal": "growth",
    "brand": { "name": "Apex Estates", "voice": "premium, data-driven" }
  }'
```

### CLI

```bash
npm run factory -- --niche "luxury real estate" --audience "US investors"
```

### Health

```bash
curl http://localhost:3100/health
```

Assets are served at `/assets/<jobId>.mp4` so Buffer can fetch public media URLs.

## n8n

Import `n8n/content-factory-workflow.json`.

Typical flow:

1. Cron / webhook → `POST /production/run`
2. Poll `GET /jobs/:id` until `status=completed`
3. Optional Slack notification

Keep business logic in this app; use n8n for schedules, webhooks, and external glue.

## Production notes

- SQLite under `storage/factory.db` (swap to Postgres for multi-node)
- Jobs are idempotent by `job_id`
- QC minimum score defaults to 85 (`QC_MIN_SCORE`)
- Max 2 visual revisions (`MAX_REVISIONS`)
- Buffer posts default to **draft** for safety
- Render prefers HyperFrames CLI; falls back to a real ffmpeg slate only if HyperFrames is unavailable so the pipeline never hangs

## Project layout

```
src/
  agents/       # Research, Strategy, Hook, Script, Visual, QC
  core/         # Director orchestration
  services/     # LLM, HyperFrames, Buffer
  api/          # Express routes
  db/           # SQLite
  cli/          # factory runner
hyperframes/    # templates & components (extend here)
storage/        # projects, renders, assets, db
n8n/            # workflow export
```

## Extending templates

Add new templates under `hyperframes/templates/` and teach the Visual Director which names are allowed in `src/agents/visual.ts`.

The composition builder in `src/services/hyperframes.ts` already produces valid HyperFrames HTML with GSAP timelines and `data-*` timing attributes.
